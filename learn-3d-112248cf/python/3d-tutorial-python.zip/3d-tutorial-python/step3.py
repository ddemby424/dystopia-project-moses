# STEP 3 - Build two rooms + a hallway out of cubes (with colliders)
from ursina import *

app = Ursina()
H = 3  # wall height

def wall(x1, z1, x2, z2):
    """A brick wall from corner (x1,z1) to corner (x2,z2)."""
    sx, sz = max(abs(x2 - x1), 0.3), max(abs(z2 - z1), 0.3)
    return Entity(model='cube', collider='box', texture='brick',
                  texture_scale=(max(sx, sz) / 2, H / 2), color=color.rgb32(210, 130, 110),
                  position=((x1 + x2) / 2, H / 2, (z1 + z2) / 2), scale=(sx, H, sz))

Entity(model='plane', scale=(40, 1, 20), texture='white_cube', texture_scale=(40, 20),
       color=color.gray, collider='box')

for side in (-1, 1):                    # side=-1 -> left room, side=+1 -> right room
    inner, outer = 3 * side, 13 * side  # room spans x 3..13 (mirrored)
    wall(inner, 5, outer, 5)            # back wall
    wall(inner, -5, outer, -5)          # front wall
    wall(outer, -5, outer, 5)           # far wall
    wall(inner, 1.5, inner, 5)          # doorway wall, upper part
    wall(inner, -5, inner, -1.5)        # doorway wall, lower part

wall(-3, 1.5, 3, 1.5)                   # hallway walls
wall(-3, -1.5, 3, -1.5)

EditorCamera(rotation=(45, 0, 0))
camera.position = (0, 0, -40)
app.run()
