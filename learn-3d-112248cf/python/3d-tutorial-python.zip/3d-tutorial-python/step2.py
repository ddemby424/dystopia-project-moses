# STEP 2 - Models, textures, position & scale
from ursina import *

app = Ursina()

floor = Entity(model='plane', scale=(20, 1, 20), texture='grass', texture_scale=(10, 10))
wall  = Entity(model='cube', position=(0, 1.5, 5), scale=(10, 3, 0.3),
               texture='brick', texture_scale=(5, 2), color=color.rgb32(200, 120, 100))

EditorCamera()
app.run()
