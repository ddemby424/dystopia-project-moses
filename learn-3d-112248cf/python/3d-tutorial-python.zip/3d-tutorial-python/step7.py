# STEP 7 - Lighting (the finished project!)
from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController

app = Ursina()
H = 3  # wall height

def wall(x1, z1, x2, z2):
    """A brick wall from corner (x1,z1) to corner (x2,z2)."""
    sx, sz = max(abs(x2 - x1), 0.3), max(abs(z2 - z1), 0.3)
    return Entity(model='cube', collider='box', texture='brick',
                  texture_scale=(max(sx, sz) / 2, H / 2), color=color.rgb32(210, 130, 110),
                  position=((x1 + x2) / 2, H / 2, (z1 + z2) / 2), scale=(sx, H, sz))

Entity(model='plane', scale=(40, 1, 20), texture='white_cube', texture_scale=(40, 20),
       color=color.gray, collider='box')

for side in (-1, 1):                    # side=-1 -> left room, side=+1 -> right room
    inner, outer = 3 * side, 13 * side  # room spans x 3..13 (mirrored)
    wall(inner, 5, outer, 5)            # back wall
    wall(inner, -5, outer, -5)          # front wall
    wall(outer, -5, outer, 5)           # far wall
    wall(inner, 1.5, inner, 5)          # doorway wall, upper part
    wall(inner, -5, inner, -1.5)        # doorway wall, lower part

wall(-3, 1.5, 3, 1.5)                   # hallway walls
wall(-3, -1.5, 3, -1.5)

player = FirstPersonController(position=(-8, 1, 0), speed=6)  # WASD + mouse, space = jump
# colliders on the walls stop you walking through them. Press Esc to quit.

# The hand: parented to the CAMERA so it follows your view (a 'viewmodel')
skin = color.rgb32(230, 180, 140)
hand = Entity(parent=camera, position=(0.45, -0.45, 0.9), rotation=(10, -15, 0))
Entity(parent=hand, model='cube', scale=(0.25, 0.1, 0.3), color=skin)           # palm
for i in range(4):                                                               # fingers
    Entity(parent=hand, model='cube', scale=(0.05, 0.06, 0.18), color=skin,
           position=(-0.09 + i * 0.06, 0, 0.22))
Entity(parent=hand, model='cube', scale=(0.06, 0.06, 0.14), color=skin,
       position=(-0.15, 0, 0.05), rotation=(0, -40, 0))                         # thumb
Entity(parent=hand, model='cube', scale=(0.2, 0.09, 0.4), color=color.rgb32(40, 40, 60),
       position=(0, 0, -0.3))                                                    # sleeve

# Bobbing: move the hand along a sine wave, but only while walking
t = 0
def update():
    global t
    moving = held_keys['w'] or held_keys['a'] or held_keys['s'] or held_keys['d']
    if moving:
        t += time.dt * 10
    else:
        t = lerp(t, round(t / 3.1416) * 3.1416, time.dt * 5)   # ease back to rest
    hand.y = -0.45 + abs(sin(t)) * -0.04
    hand.x = 0.45 + sin(t) * 0.03

# Lighting: a sun that casts shadows + soft ambient fill + a sky
from ursina.shaders import lit_with_shadows_shader
for e in scene.entities:              # make everything react to light
    if e.model: e.shader = lit_with_shadows_shader
sun = DirectionalLight(shadows=True, color=color.rgb32(255, 235, 200))
sun.look_at(Vec3(1, -1, 1))
AmbientLight(color=color.rgba32(90, 90, 110, 255))
Sky()


app.run()
