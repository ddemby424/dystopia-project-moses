# STEP 1 - The app and your first Entity
from ursina import *

app = Ursina()                         # opens the game window

cube = Entity(model='cube', color=color.orange, texture='white_cube')

def update():                          # runs every frame (~60x per second)
    cube.rotation_y += 90 * time.dt    # time.dt = seconds since last frame

EditorCamera()                         # right-drag to orbit, scroll to zoom
app.run()
