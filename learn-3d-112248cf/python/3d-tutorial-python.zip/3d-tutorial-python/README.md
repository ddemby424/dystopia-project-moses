# Learn 3D in Python (Ursina) - two brick rooms, a hallway & an FPS hand

Step 0 (in TUTORIAL.md) explains libraries, pip and imports. Then 7 tiny steps, and each file runs by itself.

## Install (5 minutes)
**Windows:** install Python 3.10+ from python.org (tick "Add Python to PATH"), then in PowerShell:
```
pip install ursina
python step1.py
```
**Mac:** install Python 3.10+ from python.org (or `brew install python`), then in Terminal:
```
pip3 install ursina
python3 step1.py
```
Close a game window with Esc / the red X. Repeat for step2.py ... step7.py.

| Step | Concept | You should see |
|---|---|---|
| 1 | App, Entity, update() loop, time.dt | A spinning orange cube |
| 2 | Models, textures, position/scale | A brick wall on grass |
| 3 | Rooms from cubes + colliders | Two rooms and a hall, seen from above |
| 4 | FirstPersonController | You can walk (WASD, mouse, space) and walls stop you |
| 5 | Hand parented to camera (viewmodel) | A blocky hand bottom-right that turns with you |
| 6 | Bobbing with sin() and time.dt | The hand bobs while you walk |
| 7 | Lighting & shadows | Sunlight, shading, shadows, a sky |

The full walkthrough is in TUTORIAL.md.
